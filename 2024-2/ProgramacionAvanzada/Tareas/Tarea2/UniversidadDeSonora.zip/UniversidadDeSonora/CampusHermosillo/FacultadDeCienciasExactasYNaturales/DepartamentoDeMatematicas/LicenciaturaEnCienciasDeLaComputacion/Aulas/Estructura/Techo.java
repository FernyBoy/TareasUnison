package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Estructura;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Se encuentra en la parte superior de la estructura y tiene la funcionalidad de poder cubrir la
 * habitación de las inclemencias del tiempo, así como la lluvia, el sol o el viento.
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Techo {}