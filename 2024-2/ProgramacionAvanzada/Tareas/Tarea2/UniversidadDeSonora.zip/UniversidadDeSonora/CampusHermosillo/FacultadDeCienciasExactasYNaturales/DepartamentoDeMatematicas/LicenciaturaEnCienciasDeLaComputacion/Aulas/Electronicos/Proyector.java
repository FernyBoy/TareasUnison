package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Electronicos;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Este periférico cuenta con la funcionalidad de convertir la señal de video enviada por una computadora
 * y transformala en imágnes a través de un cañón de luz.
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Proyector {}