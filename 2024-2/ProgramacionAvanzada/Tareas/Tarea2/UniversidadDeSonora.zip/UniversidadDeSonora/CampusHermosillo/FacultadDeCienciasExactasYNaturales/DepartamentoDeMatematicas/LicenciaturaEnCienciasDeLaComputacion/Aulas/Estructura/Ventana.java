package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Estructura;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Esta parte de la estructura tiene la funcionalidad de poder hacer una habertura en la pared de la 
 * habitación y cubrirla con un marco para así poder ver a través de la pared o dejar pasar una corriente
 * de aire.
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Ventana {}