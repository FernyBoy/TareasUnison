package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Electronicos;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Este aparato electrónico tiene la funcionalidad de mantener a cierta temperatura deseada el lugar
 * en el que haya sido instalado.
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class AireAcondicionado {}