package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Electronicos;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Este periferico es conectado a una computadora para interpretar las señales de video enviadas por
 * esta misma y convertirlas en imágenes.
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Pantalla {}