package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Muebles;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Sirve para proporcionar un asiento cómodo y estable para el usuario, permitiendo
 * descansar o realizar actividades en una posición sentada. 
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Silla {}