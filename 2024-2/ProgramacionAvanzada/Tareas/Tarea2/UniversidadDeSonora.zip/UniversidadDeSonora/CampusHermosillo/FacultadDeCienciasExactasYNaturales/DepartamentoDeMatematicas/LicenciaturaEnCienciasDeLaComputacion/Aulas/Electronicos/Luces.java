package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Electronicos;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Estos dispositivos tienen la funcionalidad de mantener iluminada la habitación donde se encuentren.
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Luces {}