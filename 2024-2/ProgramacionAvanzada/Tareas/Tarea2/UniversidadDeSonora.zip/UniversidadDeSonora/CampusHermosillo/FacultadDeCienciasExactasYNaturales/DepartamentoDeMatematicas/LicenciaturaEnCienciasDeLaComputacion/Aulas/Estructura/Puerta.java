package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Estructura;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Sirve para permitir o restringir el acceso a una habitación, ofreciendo 
 * seguridad, privacidad y control sobre quién puede entrar o salir. 
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Puerta {}