package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Muebles;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Recipiente utilizado para recolectar y contener desechos hasta que puedan 
 * ser eliminados o reciclados.
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Basura {}