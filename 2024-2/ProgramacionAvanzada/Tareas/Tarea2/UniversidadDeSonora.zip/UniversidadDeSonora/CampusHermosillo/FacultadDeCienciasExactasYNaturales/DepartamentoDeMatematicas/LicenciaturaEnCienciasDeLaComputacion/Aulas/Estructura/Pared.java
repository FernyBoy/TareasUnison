package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Estructura;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * sirve para dividir y delimitar espacios dentro de la estructura, proporcionando 
 * privacidad, soporte estructural y protección contra el clima exterior. 
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Pared {}