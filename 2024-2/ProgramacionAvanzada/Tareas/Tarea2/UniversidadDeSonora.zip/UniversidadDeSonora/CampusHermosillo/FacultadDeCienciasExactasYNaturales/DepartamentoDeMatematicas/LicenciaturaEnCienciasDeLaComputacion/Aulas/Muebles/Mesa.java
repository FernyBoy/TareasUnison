package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Muebles;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Cuenta con una superficie plana que sirve para colocar objetos y trabajar.
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Mesa {}