package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Muebles;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Superficie especial para poder trabajar de manera más cómoda y organizada. 
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Escritorio {}