package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Electronicos;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Este periferico es conectado al gabinete de una computadora para poder controlar el cursor 
 * en pantalla.
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Mouse {}