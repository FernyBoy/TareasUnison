package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Estructura;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Este dispositivo es instalado en las paredes de una habitación para poder controlar las luces que hay 
 * en esta.
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Apagadores {}