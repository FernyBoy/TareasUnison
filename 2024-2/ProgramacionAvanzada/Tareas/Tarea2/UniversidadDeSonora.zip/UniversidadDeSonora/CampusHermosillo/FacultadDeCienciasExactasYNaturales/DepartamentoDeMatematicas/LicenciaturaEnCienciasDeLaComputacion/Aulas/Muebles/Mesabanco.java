package UniversidadDeSonora.CampusHermosillo.FacultadDeCienciasExactasYNaturales.DepartamentoDeMatematicas.LicenciaturaEnCienciasDeLaComputacion.Aulas.Muebles;

/**
 * --------------------------------------------------------------------------------------------------------
 * 
 * Descripcion:
 * Es un mueble combinado que integra una mesa y un asiento. Sirve para que los estudiantes
 * tengan un lugar donde serntarse y una superficie para escribir.
 * 
 * @date 20/08/2024
 * @author Borquez Guerrero Angel Fernando
 * @expediente 219208106  
 *
 * --------------------------------------------------------------------------------------------------------
 */

class Mesabanco {}