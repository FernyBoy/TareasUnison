package unison.lcc.Electronicos;

import unison.lcc.Electronico;

public class Mouse extends Electronico
{
    public Mouse()
    {
        this.nombre = "Mouse";
    }
}