package unison.lcc.Electronicos;

import unison.lcc.Electronico;

public class Monitor extends Electronico
{
    public Monitor()
    {
        this.nombre = "Monitor";
    }
}
