package unison.lcc.Muebles;

import unison.lcc.Inanimado;

public class SillaOficina extends Inanimado
{
    public SillaOficina()
    {
        this.nombre = "SillaOficina";
    }
}
