package unison.lcc.Electronicos;

import unison.lcc.Electronico;

public class Proyector extends Electronico
{
    public Proyector()
    {
        this.nombre = "Proyector";
    }
}
