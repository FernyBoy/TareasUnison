package unison.lcc.Electronicos;

import unison.lcc.Electronico;

public class CajaFusible extends Electronico
{
    public CajaFusible()
    {
        this.nombre = "CajaFusible";
    }
}