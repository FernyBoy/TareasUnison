package unison.lcc.Personas;

import unison.lcc.Persona;

public class Estudiante extends Persona
{
    public Estudiante()
    {
        this.nombre = "Estudiante";
    }
}