package unison.lcc.Personas;

import unison.lcc.Persona;

public class Profesor extends Persona
{
    public Profesor()
    {
        this.nombre = "Profesor";
    }
}