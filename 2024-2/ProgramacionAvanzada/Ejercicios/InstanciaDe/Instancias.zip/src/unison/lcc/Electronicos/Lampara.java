package unison.lcc.Electronicos;

import unison.lcc.Electronico;

public class Lampara extends Electronico
{
    public Lampara()
    {
        this.nombre = "Lampara";
    }
}
