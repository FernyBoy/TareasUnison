package unison.lcc.Electronicos;

import unison.lcc.Electronico;

public class Teclado extends Electronico
{
    public Teclado()
    {
        this.nombre = "Teclado";
    }
}
