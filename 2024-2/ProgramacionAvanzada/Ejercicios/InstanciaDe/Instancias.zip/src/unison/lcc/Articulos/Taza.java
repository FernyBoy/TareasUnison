package unison.lcc.Articulos;

import unison.lcc.Inanimado;

public class Taza extends Inanimado
{
    public Taza()
    {
        this.nombre = "Taza";
    }
}