package unison.lcc.Muebles;

import unison.lcc.Inanimado;

public class Mesa extends Inanimado
{
    public Mesa()
    {
        this.nombre = "Mesa";
    }
}