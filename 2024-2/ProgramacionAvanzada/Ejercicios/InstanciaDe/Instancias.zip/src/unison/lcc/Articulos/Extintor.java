package unison.lcc.Articulos;

import unison.lcc.Inanimado;

public class Extintor extends Inanimado
{
    public Extintor()
    {
        this.nombre = "Extintor";
    }
}