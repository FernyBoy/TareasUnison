package unison.lcc.Articulos;

import unison.lcc.Inanimado;

public class Taza extends Inanimado{}