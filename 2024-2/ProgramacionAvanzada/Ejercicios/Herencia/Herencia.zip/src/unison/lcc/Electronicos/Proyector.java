package unison.lcc.Electronicos;

import unison.lcc.Electronico;

public class Proyector extends Electronico{}
