package unison.lcc.Electronicos;

import unison.lcc.Electronico;

public class Monitor extends Electronico{}
