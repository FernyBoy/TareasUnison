package unison.lcc.Articulos;

import unison.lcc.Inanimado;

public class Marcador extends Inanimado{}