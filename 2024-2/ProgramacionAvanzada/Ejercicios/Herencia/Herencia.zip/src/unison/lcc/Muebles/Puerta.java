package unison.lcc.Muebles;

import unison.lcc.Inanimado;

public class Puerta extends Inanimado{}