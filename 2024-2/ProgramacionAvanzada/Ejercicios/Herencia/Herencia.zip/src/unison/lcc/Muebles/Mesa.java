package unison.lcc.Muebles;

import unison.lcc.Inanimado;

public class Mesa extends Inanimado{}