package unison.lcc.Muebles;

import unison.lcc.Inanimado;

public class Pizarron extends Inanimado{}