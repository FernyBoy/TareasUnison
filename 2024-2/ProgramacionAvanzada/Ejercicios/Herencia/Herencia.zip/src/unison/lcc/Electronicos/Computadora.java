package unison.lcc.Electronicos;

import unison.lcc.Electronico;

public class Computadora extends Electronico{}
