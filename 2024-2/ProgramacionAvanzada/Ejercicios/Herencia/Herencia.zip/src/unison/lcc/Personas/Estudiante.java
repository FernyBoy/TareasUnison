package unison.lcc.Personas;

import unison.lcc.Persona;

public class Estudiante extends Persona
{
    Persona persona = new Persona() {};
}